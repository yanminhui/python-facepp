"""
Defines manager classes.
"""

from .base import ResourceManager

