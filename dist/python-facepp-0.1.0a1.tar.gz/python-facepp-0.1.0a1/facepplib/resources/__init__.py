"""
Defines FacePP resources.
"""

from .base import BaseResource, registry
from .facial import Image, Face, FaceSet, Compare, Search

